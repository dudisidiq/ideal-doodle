#!/bin/bash

# Check if python3 is installed
if ! command -v python3 &> /dev/null; then
    echo "python3 not found. Installing..."
    apt update && apt install -y python3
fi

MIN=$1

while true; do
    python3 app.py "$MIN" --cache=".cache/*"
    sleep 5
done
