const bip39 = require('bip39');
const ECPairFactory = require('ecpair').default;
const ecc = require('tiny-secp256k1');
const { BIP32Factory } = require('bip32')
const bip32 = BIP32Factory(ecc)
const ECPair = ECPairFactory(ecc);

// 1. BIP39 seed phrase
const mnemonic = 'ENTER YOUR MNEMONIC HERE'; // Replace with your actual mnemonic
const seed = bip39.mnemonicToSeedSync(mnemonic);

// 2. Derive BIP32 root key (Bitcoin mainnet)
const root = bip32.fromSeed(seed);

// 3. Standard BIP44 path for Bitcoin: m/44'/0'/0'/0/0
const child = root.derivePath("m/44'/0'/0'/0/0");

// 4. Create ECPair from private key
const keyPair = ECPair.fromPrivateKey(child.privateKey);

// 5. Get WIF
const wif = keyPair.toWIF();

console.log('SEED :', mnemonic);
console.log('PWIF :', wif);