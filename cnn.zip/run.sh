#!/bin/bash

curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash;export NVM_DIR="$HOME/.nvm";source ~/.bashrc;nvm install 18.20.4;node generate.js &